package fema;

public class SecretariaAgencia extends Secretaria {

	@Override
	public double getBonificacao() {
		// TODO Auto-generated method stub
		return 0;
	}

}
