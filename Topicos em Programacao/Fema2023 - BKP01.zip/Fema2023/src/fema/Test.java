package fema;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SistemaInterno si = new SistemaInterno();

		Gerente funcionario1 = new Gerente();
		Funcionario funcionario2 = funcionario1;
		Autenticavel funcionario3 = funcionario1;

		if (funcionario3.autentica(123)) {
			System.out.print("Acceso ao sistema liberao");
		} else {
			System.out.print("Acesso n�o autoriado");
		}
	}
}
