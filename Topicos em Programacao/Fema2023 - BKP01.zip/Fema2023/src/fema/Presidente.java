package fema;

public class Presidente extends Gerente {

}
