package fema;

public abstract class Secretaria extends Funcionario {

}
