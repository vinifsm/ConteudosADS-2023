package fema;

public class Diretor extends Funcionario implements Autenticavel {

	@Override
	public double getBonificacao() {
		// TODO Auto-generated method stub
		return getSalario() + 10000.00;
	}

	@Override
	public boolean autentica(int senha) {
		// TODO Auto-generated method stub
		return false;
	}

}
