package fema;

public class SecretariaAdministrativa extends Secretaria {

	@Override
	public double getBonificacao() {
		// TODO Auto-generated method stub
		return 0;
	}

}
