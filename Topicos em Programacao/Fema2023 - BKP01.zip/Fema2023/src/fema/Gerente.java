package fema;

public class Gerente extends Funcionario implements Autenticavel {

	private int senha;

	public int getSenha() {
		return senha;
	}

	public double getBonificacao() {
		return getSalario() * 0.1 + 1000;
	}

	public boolean autentica(int senha) {
		if (this.senha == senha) {
			System.out.println("Acesso Permitido!");
			return true;
		} else {
			System.out.println("Acesso Negado!");
			return false;
		}
	}
// setter da senha omitido

}
