package fema;

public class SistemaInterno {

	public void login(Autenticavel fa) {
		int senha = 123;
		// Pega senha de um lugar ou de um scanner de polegar.
		// Aqui eu posso chamar o autentica!
		// Pois, todo FuncionarioAutenticavel o tem.
		boolean ok = fa.autentica(senha);
	}

}
