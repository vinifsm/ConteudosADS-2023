package fema;

public interface Autenticavel {
	boolean autentica(int senha);
}