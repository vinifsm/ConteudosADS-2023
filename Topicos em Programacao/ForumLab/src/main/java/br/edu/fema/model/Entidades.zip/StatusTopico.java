package br.edu.fema.model;

public enum StatusTopico {

	NAO_RESPONDIDO, 
	NAO_SOLUCIONADO, 
	SOLUCIONADO, 
	FECHADO;

}
