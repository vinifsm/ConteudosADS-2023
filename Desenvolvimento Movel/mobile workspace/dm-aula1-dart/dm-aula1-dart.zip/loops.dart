void main(List<String> args) {
  for (var i = 0; i < 10; i++) {
    // if (i % 2 != 0) {
    //   continue;
    // }

    // if (i >= 6) {
    //   break;
    // }

    print('Repetição: ${i}');
  }

  print('---');

  List<String> cursos = [
    'Análise e Desenv. de Sistemas',
    'Ciência da Computação',
    'Matemática',
    'Direito',
    'Administração',
    'Química'
  ];

  // print(cursos);

  for (String curso in cursos) {
    // print(curso);
    print(curso);
  }

  print('---');

  // cursos.forEach((curso) => print(curso));
  cursos.asMap().forEach((index, curso) => print('${index} - ${curso}'));

  // -- while (!concluiu()) { executar(); }
  // -- do { imprimirDados(); } while (!concluiu());
}
