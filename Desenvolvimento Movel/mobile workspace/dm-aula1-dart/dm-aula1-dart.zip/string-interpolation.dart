int calcularAnoNascimento(int idade, {int anoAtual = 2022}) {
  return anoAtual - idade;
}

void main(List<String> args) {
  String nome = 'Guilherme';
  int idade = 34;

  print('Olá, ' + nome + '. Você nasceu em ' + (2022 - idade).toString() + '.');
  print('Olá, ${nome}. Você nasceu em ${2022 - idade}.');
  print('Olá, ${nome}. Você nasceu em ${calcularAnoNascimento(idade)}.');
  print('Olá, ${nome}. Você nasceu em ${calcularAnoNascimento(idade, anoAtual: 2020)}.');
}
